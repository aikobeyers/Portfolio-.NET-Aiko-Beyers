using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

public class Album {
	public int Id { get; set; }

    [Required]
    public string Name { get; set; }

    public TimeSpan TotalLength { get; set; }

    
    public string Description { get; set; }

    
    public List<Song> Song { get; set; }

    
    public List<Artist> Artist { get; set; }

}
