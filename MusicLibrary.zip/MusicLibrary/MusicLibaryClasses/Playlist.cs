using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

public class Playlist {
	public int Id { get; set; }

    [Required]
    public string Name { get; set; }

    
    public List<Song> Songs { get; set; }

}
