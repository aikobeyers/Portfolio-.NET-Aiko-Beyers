﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MusicLibrary.DataModel;

namespace MusicLibrary.Controllers
{
    public class AlbumsController : Controller
    {
        private AlbumRepository albumRepository;

        public AlbumsController()
        {
            this.albumRepository = new AlbumRepository(new MusicLibraryContext());
        }

        // GET: Albums
        public ActionResult Index()
        {
            return View(albumRepository.GetObjects());
        }

        // GET: Albums/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Album album = albumRepository.GetObjectByID(id);
            ViewBag.Songs = album.Song;
            ViewBag.Artists = album.Artist;
            if (album == null)
            {
                return HttpNotFound();
            }
            return View(album);
        }

        // GET: Albums/Create
        public ActionResult Create()
        {
            ViewBag.SongId = new MultiSelectList(albumRepository.GetSongs(), "Id", "Title");
            ViewBag.ArtistId = new MultiSelectList(albumRepository.GetArtists(), "Id", "Name");
            return View();
        }

        // POST: Albums/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,Description", Exclude = "TotalLength")] Album album)
        {
            if (ModelState.IsValid)
            {
                
                List<int> SelectedArtists = Request.Form.GetValues("ArtistId").ToList().Select(int.Parse).ToList();
                List<Artist> artists = albumRepository.GetArtists().Where(a => SelectedArtists.Contains(a.Id)).ToList();

                List<int> SelectedSongs = Request.Form.GetValues("SongId").ToList().Select(int.Parse).ToList();
                List<Song> songs = albumRepository.GetSongs().Where(a => SelectedSongs.Contains(a.Id)).ToList();
                album.Artist = artists;
                album.Song = songs;
                
                //Album opslaan met default TotalLength omdat de Id nog niet gegenereerd is in de db
                albumRepository.InsertObject(album);
                albumRepository.Save();

                //Bovenstaand album terugophalen en op basis van het Id de TotalLength berekenen
                Album previousAlbum = albumRepository.GetObjects().LastOrDefault();
                previousAlbum.TotalLength = albumRepository.CalculateAlbumLength(previousAlbum.Id);

                albumRepository.UpdateObject(previousAlbum);
                albumRepository.Save();
                return RedirectToAction("Index");
            }

            return View(album);
        }

        // GET: Albums/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Album album = albumRepository.GetObjectByID(id);
            if (album == null)
            {
                return HttpNotFound();
            }
            ViewBag.SongId = new MultiSelectList(albumRepository.GetSongs(), "Id", "Title");
            ViewBag.ArtistId = new MultiSelectList(albumRepository.GetArtists(), "Id", "Name");
            return View(album);
        }

        // POST: Albums/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,Description")] Album album)
        {
            if (ModelState.IsValid)
            {
                albumRepository.UpdateObject(album);
                var newAlbum = albumRepository.GetObjectByID(album.Id);
                List<int> SelectedArtists = Request.Form.GetValues("ArtistId").ToList().Select(int.Parse).ToList();
                List<Artist> artists = albumRepository.GetArtists().Where(a => SelectedArtists.Contains(a.Id)).ToList();

                List<int> SelectedSongs = Request.Form.GetValues("SongId").ToList().Select(int.Parse).ToList();
                List<Song> songs = albumRepository.GetSongs().Where(a => SelectedSongs.Contains(a.Id)).ToList();
                newAlbum.Artist = artists;
                newAlbum.Song = songs;
                albumRepository.UpdateObject(newAlbum);
                newAlbum.TotalLength = albumRepository.CalculateAlbumLength(album.Id);
                
                albumRepository.UpdateObject(newAlbum);
                albumRepository.Save();
                return RedirectToAction("Index");
            }
         
            return View(album);
        }

        // GET: Albums/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Album album = albumRepository.GetObjectByID(id);
            if (album == null)
            {
                return HttpNotFound();
            }
            return View(album);
        }

        // POST: Albums/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            albumRepository.DeleteObject(id);
            albumRepository.Save();
            return RedirectToAction("Index");
        }
    }
}
