﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MusicLibrary.DataModel;

namespace MusicLibrary.Controllers
{
    public class SongsController : Controller
    {
        private SongRepository songRepository;

        public SongsController()
        {
            this.songRepository = new SongRepository(new MusicLibraryContext());
        }

        // GET: Songs
        public ActionResult Index()
        {
            var songs = songRepository.GetObjects();
            return View(songs.ToList());
        }

        // GET: Songs/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Song song = songRepository.GetObjectByID(id);
            ViewBag.Artists = song.Artist;
            
            if (song == null)
            {
                return HttpNotFound();
            }
            return View(song);
        }

        // GET: Songs/Create
        public ActionResult Create()
        {
            ViewBag.GenreId = new SelectList(songRepository.GetGenres(), "Id", "Name");
            ViewBag.ArtistId = new MultiSelectList(songRepository.GetArtists(), "Id", "Name");
            return View();
        }

        // POST: Songs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Title,Duration,Lyrics,GenreId", Exclude = "ArtistId")] Song song)
        {
            if (ModelState.IsValid)
            {
                List<int> SelectedArtists = Request.Form.GetValues("ArtistId").ToList().Select(int.Parse).ToList();
                List<Artist> artists = songRepository.GetArtists().Where(a => SelectedArtists.Contains(a.Id)).ToList();
                song.Artist = (artists);

                songRepository.InsertObject(song);
                songRepository.Save();
                
                return RedirectToAction("Index");
            }


            
            return View(song);
        }

        // GET: Songs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Song song = songRepository.GetObjectByID(id);
            
            if (song == null)
            {
                return HttpNotFound();
            }
            ViewBag.GenreId = new SelectList(songRepository.GetGenres(), "Id", "Name", song.GenreId);
            ViewBag.ArtistId = new MultiSelectList(songRepository.GetArtists(), "Id", "Name", song.Artist);
            return View(song);
        }

        // POST: Songs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Title,Duration,Lyrics,GenreId,Artist")] Song song)
        {
            if (ModelState.IsValid)
            {
                songRepository.UpdateObject(song);
                var newSong = songRepository.GetObjectByID(song.Id);
                List<int> SelectedArtists = Request.Form.GetValues("ArtistId").ToList().Select(int.Parse).ToList();
                List<Artist> artists = songRepository.GetArtists().Where(a => SelectedArtists.Contains(a.Id)).ToList();
                
                newSong.Artist = artists;

                songRepository.UpdateObject(newSong);
                songRepository.Save();
                
                
                return RedirectToAction("Index");
            }
            
            return View(song);
        }

        // GET: Songs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            
            Song song = songRepository.GetObjectByID(id);
            ViewBag.Artists = song.Artist;

            if (song == null)
            {
                return HttpNotFound();
            }
            return View(song);
        }

        // POST: Songs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
           

            songRepository.DeleteObject(id);
            songRepository.Save();
            return RedirectToAction("Index");
        }

        
    }
}
