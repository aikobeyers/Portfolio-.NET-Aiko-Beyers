﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MusicLibrary.DataModel;


namespace MusicLibrary.Controllers
{
    public class PlaylistsController : Controller
    {
        private PlaylistRepository playlistRepository;

        public PlaylistsController()
        {
            this.playlistRepository = new PlaylistRepository(new MusicLibraryContext());
        }
        

        // GET: Playlists
        public ActionResult Index()
        {
            var playlists = playlistRepository.GetObjects();
            return View(playlists.ToList());
        }

        // GET: Playlists/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Playlist playlist = playlistRepository.GetObjectByID(id);

            
            

            if (playlist == null)
            {
                {
                    return HttpNotFound();
                }
            }
            ViewBag.TotalDuration = playlistRepository.GetTotalTime(playlist.Id);
            ViewBag.Songs = playlist.Songs;
            return View(playlist);
        }

        // GET: Playlists/Create
        public ActionResult Create()
        {
            ViewBag.SongsId = new MultiSelectList(playlistRepository.GetSongs(), "Id", "Title");
            return View();
        }

        // POST: Playlists/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name", Exclude = "SongsId")] Playlist playlist)
        {
            if (ModelState.IsValid)
            {
                List<int> SelectedSongs = Request.Form.GetValues("SongsId").ToList().Select(int.Parse).ToList();
                List<Song> songs = playlistRepository.GetSongs().Where(a => SelectedSongs.Contains(a.Id)).ToList();
                playlist.Songs = songs;
                
                

                playlistRepository.InsertObject(playlist);
                playlistRepository.Save();
              
                return RedirectToAction("Index");
            }
            ViewBag.SongsId = new MultiSelectList(playlistRepository.GetSongs(), "Id", "Title");

            return View(playlist);
        }

        // GET: Playlists/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Playlist playlist = playlistRepository.GetObjectByID(id);
            if (playlist == null)
            {
                return HttpNotFound();
            }
            ViewBag.SongsId = new MultiSelectList(playlistRepository.GetSongs(), "Id", "Title");

            return View(playlist);
        }

        // POST: Playlists/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,Songs")] Playlist playlist)
        {
            if (ModelState.IsValid)
            {
                playlistRepository.UpdateObject(playlist);
                var newPlaylist = playlistRepository.GetObjectByID(playlist.Id);
                List<int> selectedSongs = Request.Form.GetValues("SongsId").ToList().Select(int.Parse).ToList();
                List<Song> songs = playlistRepository.GetSongs().Where(a => selectedSongs.Contains(a.Id)).ToList();
                newPlaylist.Songs = songs;

                playlistRepository.UpdateObject(newPlaylist);
                playlistRepository.Save();

                return RedirectToAction("Index");
            }
            ViewBag.SongsId = new MultiSelectList(playlistRepository.GetSongs(), "Id", "Title");

            return View(playlist);
        }

        // GET: Playlists/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Playlist playlist = playlistRepository.GetObjectByID(id);
            if (playlist == null)
            {
                return HttpNotFound();
            }
            return View(playlist);
        }

        // POST: Playlists/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            

            playlistRepository.DeleteObject(id);
            playlistRepository.Save();
          
            return RedirectToAction("Index");
        }

    }
}
