﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicLibrary.DataModel
{
    public interface IMusicRepository<T>
    {
       

        IEnumerable<T> GetObjects();
        T GetObjectByID(int? Id);
        void InsertObject(T obj);
        void DeleteObject(int ID);
        void UpdateObject(T obj);
        void Save();
    }
}
