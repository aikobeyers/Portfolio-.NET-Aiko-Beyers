namespace MusicLibrary.DataModel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AnnotationsTest : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Songs", "Title", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Songs", "Title", c => c.String());
        }
    }
}
