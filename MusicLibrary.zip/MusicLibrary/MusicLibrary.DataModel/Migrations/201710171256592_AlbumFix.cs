namespace MusicLibrary.DataModel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AlbumFix : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Albums", "Name", c => c.String());
            DropColumn("dbo.Albums", "naNameme");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Albums", "naNameme", c => c.String());
            DropColumn("dbo.Albums", "Name");
        }
    }
}
