namespace MusicLibrary.DataModel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AnnotationsAll : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Albums", "Name", c => c.String(nullable: false));
            AlterColumn("dbo.Albums", "Description", c => c.String(nullable: false));
            AlterColumn("dbo.Artists", "Name", c => c.String(nullable: false));
            AlterColumn("dbo.Genres", "Name", c => c.String(nullable: false));
            AlterColumn("dbo.Genres", "Description", c => c.String(nullable: false));
            AlterColumn("dbo.Playlists", "Name", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Playlists", "Name", c => c.String());
            AlterColumn("dbo.Genres", "Description", c => c.String());
            AlterColumn("dbo.Genres", "Name", c => c.String());
            AlterColumn("dbo.Artists", "Name", c => c.String());
            AlterColumn("dbo.Albums", "Description", c => c.String());
            AlterColumn("dbo.Albums", "Name", c => c.String());
        }
    }
}
