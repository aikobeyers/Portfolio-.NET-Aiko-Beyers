namespace MusicLibrary.DataModel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Albums",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        naNameme = c.String(),
                        TotalLength = c.Time(nullable: false, precision: 7),
                        Description = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Artists",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Origin = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Songs",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Title = c.String(),
                        Duration = c.Time(nullable: false, precision: 7),
                        Lyrics = c.String(),
                        GenreId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Genres", t => t.GenreId, cascadeDelete: true)
                .Index(t => t.GenreId);
            
            CreateTable(
                "dbo.Genres",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.Int(nullable: false),
                        Description = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Playlists",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.ArtistAlbums",
                c => new
                    {
                        Artist_Id = c.Int(nullable: false),
                        Album_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Artist_Id, t.Album_Id })
                .ForeignKey("dbo.Artists", t => t.Artist_Id, cascadeDelete: true)
                .ForeignKey("dbo.Albums", t => t.Album_Id, cascadeDelete: true)
                .Index(t => t.Artist_Id)
                .Index(t => t.Album_Id);
            
            CreateTable(
                "dbo.SongAlbums",
                c => new
                    {
                        Song_Id = c.Int(nullable: false),
                        Album_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Song_Id, t.Album_Id })
                .ForeignKey("dbo.Songs", t => t.Song_Id, cascadeDelete: true)
                .ForeignKey("dbo.Albums", t => t.Album_Id, cascadeDelete: true)
                .Index(t => t.Song_Id)
                .Index(t => t.Album_Id);
            
            CreateTable(
                "dbo.SongArtists",
                c => new
                    {
                        Song_Id = c.Int(nullable: false),
                        Artist_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Song_Id, t.Artist_Id })
                .ForeignKey("dbo.Songs", t => t.Song_Id, cascadeDelete: true)
                .ForeignKey("dbo.Artists", t => t.Artist_Id, cascadeDelete: true)
                .Index(t => t.Song_Id)
                .Index(t => t.Artist_Id);
            
            CreateTable(
                "dbo.PlaylistSongs",
                c => new
                    {
                        Playlist_Id = c.Int(nullable: false),
                        Song_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Playlist_Id, t.Song_Id })
                .ForeignKey("dbo.Playlists", t => t.Playlist_Id, cascadeDelete: true)
                .ForeignKey("dbo.Songs", t => t.Song_Id, cascadeDelete: true)
                .Index(t => t.Playlist_Id)
                .Index(t => t.Song_Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.PlaylistSongs", "Song_Id", "dbo.Songs");
            DropForeignKey("dbo.PlaylistSongs", "Playlist_Id", "dbo.Playlists");
            DropForeignKey("dbo.Songs", "GenreId", "dbo.Genres");
            DropForeignKey("dbo.SongArtists", "Artist_Id", "dbo.Artists");
            DropForeignKey("dbo.SongArtists", "Song_Id", "dbo.Songs");
            DropForeignKey("dbo.SongAlbums", "Album_Id", "dbo.Albums");
            DropForeignKey("dbo.SongAlbums", "Song_Id", "dbo.Songs");
            DropForeignKey("dbo.ArtistAlbums", "Album_Id", "dbo.Albums");
            DropForeignKey("dbo.ArtistAlbums", "Artist_Id", "dbo.Artists");
            DropIndex("dbo.PlaylistSongs", new[] { "Song_Id" });
            DropIndex("dbo.PlaylistSongs", new[] { "Playlist_Id" });
            DropIndex("dbo.SongArtists", new[] { "Artist_Id" });
            DropIndex("dbo.SongArtists", new[] { "Song_Id" });
            DropIndex("dbo.SongAlbums", new[] { "Album_Id" });
            DropIndex("dbo.SongAlbums", new[] { "Song_Id" });
            DropIndex("dbo.ArtistAlbums", new[] { "Album_Id" });
            DropIndex("dbo.ArtistAlbums", new[] { "Artist_Id" });
            DropIndex("dbo.Songs", new[] { "GenreId" });
            DropTable("dbo.PlaylistSongs");
            DropTable("dbo.SongArtists");
            DropTable("dbo.SongAlbums");
            DropTable("dbo.ArtistAlbums");
            DropTable("dbo.Playlists");
            DropTable("dbo.Genres");
            DropTable("dbo.Songs");
            DropTable("dbo.Artists");
            DropTable("dbo.Albums");
        }
    }
}
