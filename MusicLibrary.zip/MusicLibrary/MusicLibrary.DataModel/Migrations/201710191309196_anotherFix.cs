namespace MusicLibrary.DataModel.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class anotherFix : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
