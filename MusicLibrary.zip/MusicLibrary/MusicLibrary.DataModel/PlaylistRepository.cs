﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace MusicLibrary.DataModel
{
    public class PlaylistRepository : IMusicRepository<Playlist>
    {
        private MusicLibraryContext context;



        public PlaylistRepository(MusicLibraryContext context)
        {
            this.context = context;
        }

        public void DeleteObject(int Id)
        {
            Playlist playlist = context.Playlists.Find(Id);
            context.Playlists.Remove(playlist);
        }

        public Playlist GetObjectByID(int? Id)
        {
            return context.Playlists.Include(p => p.Songs).FirstOrDefault(p => p.Id == Id);
        }

        public IEnumerable<Playlist> GetObjects()
        {
            var playlists = context.Playlists.Include(s => s.Songs);
            return playlists;
        }

        public void InsertObject(Playlist obj)
        {
            context.Playlists.Add(obj);
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void UpdateObject(Playlist obj)
        {
            context.Entry(obj).State = EntityState.Modified;
        }

        public int GetTotalTime(int id)
        {
            SqlParameter param1 = new SqlParameter("@p_id", id);
            return context.Database.SqlQuery<int>("get_playlist_duration @p_id", param1).Single();
        }

        public List<Song> GetSongs()
        {
            return context.Songs.ToList();
        }
    }
}
