﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;

namespace MusicLibrary.DataModel
{
    public class SongRepository : IMusicRepository<Song>
    {
        private MusicLibraryContext context;

        public SongRepository(MusicLibraryContext context)
        {
            this.context = context;
        }

        public void DeleteObject(int Id)
        {
            Song song = context.Songs.Find(Id);
            context.Songs.Remove(song);
        }

        public Song GetObjectByID(int? Id)
        {
            return context.Songs.Include(s => s.Genre).Include(s => s.Artist).FirstOrDefault(s => s.Id == Id); 
        }

        public IEnumerable<Song> GetObjects()
        {

            var songs = context.Songs.Include(s => s.Genre).Include(t => t.Artist);  
            return songs.ToList();
        }
        public void InsertObject(Song obj)
        {

            context.Songs.Add(obj);
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void UpdateObject(Song obj)
        {
            context.Entry(obj).State = EntityState.Modified;
        }

        public List<Genre> GetGenres()
        {
            return context.Genre.ToList();
        }

        public List<Artist> GetArtists()
        {
            return context.Artists.ToList();
        }
    }
}
