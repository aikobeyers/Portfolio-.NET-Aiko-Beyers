﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;

namespace MusicLibrary.DataModel
{
   public class GenreRepository : IMusicRepository<Genre>
    {
        private MusicLibraryContext context;



        public GenreRepository(MusicLibraryContext context)
        {
            this.context = context;
        }

        public void DeleteObject(int Id)
        {
            Genre genre = context.Genre.Find(Id);
            context.Genre.Remove(genre);
        }

        public Genre GetObjectByID(int? Id)
        {
            return context.Genre.Find(Id);
        }

        public IEnumerable<Genre> GetObjects()
        {
            var genres = context.Genre.ToList();
            return genres;
        }

        public void InsertObject(Genre obj)
        {
            context.Genre.Add(obj);
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void UpdateObject(Genre obj)
        {
            context.Entry(obj).State = EntityState.Modified;
        }

        public List<Song> GetSongsByGenre(int id)
        {
            return context.Songs.Where(s => s.GenreId == id).ToList();
        }
    }
}
