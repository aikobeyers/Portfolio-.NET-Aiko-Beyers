﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;

namespace MusicLibrary.DataModel
{
    public class ArtistRepository : IMusicRepository<Artist>
    {
        private MusicLibraryContext context;

        public ArtistRepository(MusicLibraryContext context)
        {
            this.context = context;
        }

        public void DeleteObject(int Id)
        {
            Artist artist = context.Artists.Find(Id);
            context.Artists.Remove(artist);
        }

        public Artist GetObjectByID(int? Id)
        {
            return context.Artists.Include(a => a.Song).Include(a => a.Album).FirstOrDefault(a => a.Id == Id);
        }

        public IEnumerable<Artist> GetObjects()
        {
            var artists = context.Artists.ToList();
            return artists;
        }

        public void InsertObject(Artist obj)
        {
            context.Artists.Add(obj);
            
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void UpdateObject(Artist obj)
        {
            context.Entry(obj).State = EntityState.Modified;
        }
    }
}
