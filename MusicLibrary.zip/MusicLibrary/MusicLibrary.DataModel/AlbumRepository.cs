﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace MusicLibrary.DataModel
{
    public class AlbumRepository : IMusicRepository<Album>
    {
        private MusicLibraryContext context;



        public AlbumRepository(MusicLibraryContext context)
        {
            this.context = context;
        }

        public void DeleteObject(int Id)
        {
            Album album = context.Albums.Find(Id);
            context.Albums.Remove(album);
        }

        public Album GetObjectByID(int? Id)
        {
            return context.Albums.Include(a => a.Song).Include(a => a.Artist).FirstOrDefault(a => a.Id == Id);
        }

        public IEnumerable<Album> GetObjects()
        {
            var albums = context.Albums.Include(a => a.Song).Include(a => a.Artist);
            return albums.ToList();
        }

        public void InsertObject(Album obj)
        {
            context.Albums.Add(obj);
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void UpdateObject(Album obj)
        {
            context.Entry(obj).State = EntityState.Modified;
        }

        public List<Artist> GetArtists()
        {
            return context.Artists.ToList();
        }

        public List<Song> GetSongs()
        {
            return context.Songs.ToList();
        }

        public TimeSpan CalculateAlbumLength(int albumId)
        {
            string cmdText = @"Select TotalTime = DATEADD(s, SUM(DATEDIFF(s, '00:00:00', s.Duration)), '00:00:00')
                               From Albums a
                               Inner Join SongAlbums as sa
                                    on a.Id = sa.Album_Id
                               Inner Join Songs as s
                                    on sa.Song_Id = s.Id
                               where a.Id = " + albumId.ToString();
            var dt = context.Database.SqlQuery<DateTime>( cmdText).Single();
     
            return dt.TimeOfDay;
        }

      
    }
}
