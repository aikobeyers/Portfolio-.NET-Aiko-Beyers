﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE get_playlist_duration 
	-- Add the parameters for the stored procedure here
	@p_id int = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	Select Total_time=SUM(DATEDIFF(MINUTE, '0:00:00', s.Duration))
	From Playlists p
	Inner Join PlaylistSongs as ps
		on p.Id = ps.Playlist_Id
	Inner Join Songs as s
		on ps.Song_Id = s.Id
	where p.Id = @p_id
END